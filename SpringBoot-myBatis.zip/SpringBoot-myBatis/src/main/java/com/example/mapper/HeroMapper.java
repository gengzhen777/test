package com.example.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.example.entity.Hero;
//指定这是一个操作数据库的mapper
@Mapper
public interface HeroMapper {
	@Select("select * from hero where hid<#{hid}")
	public List<Hero> getHeroById(Integer hid);
	@Delete("delete from hero where hid=#{hid}")
	public boolean deleteHeroById(Integer hid); 
	@Insert("insert into hero(countryid,hname,hpwd) values(#{countryid},#{hname},#{hpwd})")
	public boolean addHero(Hero hero);
}
