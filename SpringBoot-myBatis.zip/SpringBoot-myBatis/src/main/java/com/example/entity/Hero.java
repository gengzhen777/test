package com.example.entity;

public class Hero {
	private int hid;
	private int countryid;
	private String hname;
	private String hpwd;
	public int getHid() {
		return hid;
	}
	public void setHid(int hid) {
		this.hid = hid;
	}
	public int getCountryid() {
		return countryid;
	}
	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public String getHpwd() {
		return hpwd;
	}
	public void setHpwd(String hpwd) {
		this.hpwd = hpwd;
	}
}
