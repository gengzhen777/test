package com.example.controller.son;

import java.util.List;

import javax.annotation.Resource;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.Hero;
import com.example.mapper.HeroMapper;


@RestController
@EnableAutoConfiguration
@MapperScan(basePackages="com.example.mapper")
public class HeroController {
	@Resource
	private HeroMapper heroMapper;
	@RequestMapping("/hero")
	public List<Hero> getHeroById(Integer hid) {
		System.out.println("hid:"+hid);
		List<Hero> list = heroMapper.getHeroById(hid);
		return list;
	}
	public static void main(String[] args) {
		SpringApplication.run(HeroController.class, args);
	}
}
